

class DatatypeError < RuntimeError
end 

class OperatorError < RuntimeError 
end

class DeclarationError < RuntimeError 
end 

class ReturnError < RuntimeError
end 