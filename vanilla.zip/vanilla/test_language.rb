require './test_functions.rb'
require './test_datatypes.rb'
require './test_expressions.rb'
require './test_statements.rb'